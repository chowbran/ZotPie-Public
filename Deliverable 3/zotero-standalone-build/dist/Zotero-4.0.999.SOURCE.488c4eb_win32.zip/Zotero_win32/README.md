Zotero
======
[![Build Status](https://travis-ci.org/zotero/zotero.svg?branch=4.0)](https://travis-ci.org/zotero/zotero)

Zotero is a free, easy-to-use tool to help you collect, organize, cite, and share your research sources.

For more information on how to use this source code, see the [Zotero wiki](http://www.zotero.org/support/dev/source_code).
